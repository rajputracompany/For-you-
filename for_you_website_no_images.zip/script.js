const button = document.getElementById("surpriseBtn");
const message = document.getElementById("message");

button.addEventListener("click", () => {
  message.classList.remove("hidden");
  button.textContent = "Surprise opened ❤️";
  createHearts(18);

  message.scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
});

function createHearts(amount) {
  for (let i = 0; i < amount; i++) {
    const heart = document.createElement("div");
    heart.className = "heart";
    heart.textContent = Math.random() > 0.5 ? "❤️" : "💗";
    heart.style.left = Math.random() * 100 + "vw";
    heart.style.fontSize = (14 + Math.random() * 22) + "px";
    heart.style.animationDuration = (3 + Math.random() * 3) + "s";
    document.body.appendChild(heart);

    setTimeout(() => heart.remove(), 6500);
  }
}
